#include <iostream>
#include <math.h>
#include <stdlib.h>
using namespace std;
const int ERROR_EXIT= -1331;
int main()
{
    int base=0;
    int length=0;
    int value=0;
    cout<<"This code will convert any codeword to Gray code"<<endl<<endl;
    cout<<"enter base:"<<endl;
    cin>>base;
    cout<<endl;
    cout<<"enter the length:  ";
    cin>>length;
    cout<<endl;
    cout<<"enter the value: ";
    cin>>value;
    if((base<=1) || (length<=1))
    {
        cout<<"incompatible inputs"<<endl;
        exit(ERROR_EXIT);
    }
    //local variables
    int gray[length];
    int baseN[length];
    int i;
    //put the normal baseN number into the baseN array
    for(i=0; i<length; i++)
    {
        baseN[i]=value%base;
        value=value/base;
    }

    //convert number into Gray code equivalent
    int shift=0;
    cout<<endl;
    while(i--)
    {
        gray[i]= (baseN[i]+shift)%base;
        //cout<<gray[i]<<" ";
        shift = shift + base -gray[i]; //subtract from base so shift positive
    }
    for(int o=0; o<length; o++)
        cout<<gray[o];
    cout<<endl;
    system("pause");
    return 0;
}
