#include <iostream>
#include <stdlib.h>

using namespace std;
const int ERROR_EXIT=-1131;
void initialise ( int arr[], int length);
void display ( int arr[], int length);
void dectob(int arr[], int n, int length, int q);
int main()
{
    cout << "this program generates all balancing sequences of length n and alphabet size q" << endl;
    int n=0;
    int q=0;
    cout<<"enter the length:  ";
    cin>>n;
    cout<<endl<<"enter the alphabet size:  ";
    cin>>q;

    if(((n%2==1) &&(q%2==0)) || (n<=1) || (q<=1))
    {
        cout<<endl<<"incompatible parameters"<<endl;
        exit(ERROR_EXIT);
    }
    int pos[2]; //array containing s and p values.
    int balancing[n];//array containing the balancing sequence.

    initialise(balancing, n);
    initialise(pos,2);
    cout<<endl<<"There are "<<n*q<<" possible balancing sequences."<<endl;
    cout<<endl<<"c    "<<"a    "<<"b    "<<"balancing sequence   "<<endl<<endl;
    for(int z=0; z<(n*q); z++)
    {
        dectob(pos, z, 2, n);
        cout<<z<<"    ";
        display(pos, 2);
        cout<<"|  ";
        for (int i=0; i<n; i++)
        {
            if(i>=pos[1])
                balancing[i]=pos[0];
            else
                balancing[i]=pos[0]+1;
        }
        display (balancing, n);

        cout<<endl;

    }

    return 0;
}
void initialise ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    arr[c]=0;
}

void display ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    cout<<arr[c]<<"    ";
}
void dectob(int arr[], int n, int length, int q)
{
    int rem=0;
    int i=0;
    if(n<q)
    {
        arr[length-1]=n;
    }
    while(n!=0)
    {
        rem=n%q;
        arr[length -i-1]=rem;
        i++;
        n/=q;
    }
}
