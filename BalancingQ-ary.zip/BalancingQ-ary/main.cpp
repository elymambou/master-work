#include <iostream>
#include <stdlib.h>

using namespace std;

void display ( int arr[], int length);
void initialise ( int arr[], int length);
const int ERROR_EXIT=-4664;
void dectob(int arr[], int n, int length, int q);
void balacingSeq (int balancing[], int pos[], int length, int z);
int main()
{
    cout << "This program will balance any codeword entered by the user" << endl<<endl;
    int n=0;
    int q=0;
    cout<<"enter the length:  ";
    cin>>n;
    cout<<endl<<"enter the alphabet size:  ";
    cin>>q;

    int codeword[n];
    int balancing[n];
    int balanced[n];
    int pos[2];
    initialise(codeword, n);
    initialise(balancing, n);
    initialise(balanced, n);
    initialise(pos,2);


    if(((n%2==1)&&(q%2==0)) || (n<=1) || (q<=1))
    {
        cout<<endl<<"incompatible parameters"<<endl;
        exit(ERROR_EXIT);
    }
    int input=0;
    int bal =n*(q-1)/2;
    int sum=0;
    int counter=0;
    cout<<endl<<"Enter the codeword"<<endl;
    for(int a=0; a<n; a++)
    {
        cin>>input;
        if(input<0 || input>=q)
        {
        cout<<endl<<"wrong input"<<endl;
        exit(ERROR_EXIT);
        }
        else
        codeword[a]=input;
    }
    cout<<endl<<"Here is the codeword that you entered:  ";
    display(codeword, n);
    cout<<". And the balancing value is "<<bal;
    cout<<endl<<endl;

    for(int z=0; z<n*q; z++)
    {
        balacingSeq(balancing, pos, n, z);
        for(int i=0; i<n; i++)
        {
            balanced[i]=(codeword[i]+balancing[i])%q;
            sum=sum+balanced[i];

        }
        display(codeword, n);cout<<" +  ";
        display(balancing,n); cout<<" =  ";
        display(balanced,n);
        cout<<"    "<<sum;
        if(sum == bal)
        {
            cout<<"  balanced  ";
            for(int y=0; y<n; y++)
            cout<<balanced[y];
            counter++;
        }

        cout<<endl;
        sum=0;

    }
    cout<<endl<<"there are "<<counter<<" possible balanced codewords "<<endl;
    return 0;
}

void initialise ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    arr[c]=0;
}

void display ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    cout<<arr[c]<<" ";
}
void dectob(int arr[], int n, int length, int q)
{
    int rem=0;
    int i=0;
    while(n!=0)
    {
        rem=n%q;
        n/=q;
        arr[length -i-1]=rem;
        i++;

    }
}

void balacingSeq ( int balancing[], int pos[], int n, int z)
{
        dectob(pos, z, 2, n);
        for (int i=0; i<n; i++)
        {
            if(i>=pos[1])
                balancing[i]=pos[0];
            else
                balancing[i]=pos[0]+1;
        }
}
