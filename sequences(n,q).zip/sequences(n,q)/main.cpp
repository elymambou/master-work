#include <iostream>
#include <math.h>
#include <stdlib.h>

using namespace std;

/*Elie Mambou
university of Johannesburg*/

void initialise ( int arr[], int length);
void display ( int arr[], int length);
void dectob(int arr[], int n, int length, int q);

int main()
{
    int n=0;
    int q=0;
    cout<<"This code will display all sequences of length `n' in base `q'."<<endl<<endl;
    cout<<"q and n can be any value greater or equal to 2. n can not be odd when q is even."<<endl<<endl;
    cout<<"enter the length:  ";
    cin>>n;
    cout<<endl<<"enter the alphabet size:  ";
    cin>>q;
    int codeword[n];
    if(q%2==0)
    {
        for (int i=0; i<(pow(q,n)); i++)
        {
        initialise(codeword, n);
        dectob(codeword,i,n,q);

        display(codeword, n);
        cout<<"    "<<i;
        cout<<endl;

        }
   }
    else
   {
       for (int i=0; i<(pow(q,n)-1); i++)
        {
        initialise(codeword, n);
        dectob(codeword,i,n,q);

        display(codeword, n);
        cout<<"    "<<i;
        cout<<endl;

        }
   }

    //delete [] codeword;
    //codeword=0;

    cout<<endl<<"the cardinality of "<<q<<"-ary of length "<<n<<" is "<<pow(q,n)<<" codewords "<<endl;
    system("pause");
    return 0;
}

void initialise ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    arr[c]=0;
}

void display ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    cout<<arr[c]<<" ";
}

void dectob(int arr[], int n, int length, int q)
{
    int rem=0;
    int i=0;
    /*if(n<q)
    {
        arr[length-1]=n;
    }*/
    while(n!=0)
    {
        rem=n%q;
        n=n/q;
        arr[length -i-1]=rem;
        i++;

    }
}
