#include <iostream>
#include <math.h>
#include <stdlib.h>

using namespace std;
const int ERROR_EXIT=-4664;

int main()
{
    int n=0;
    int q=0;
    cout<<"This code will display all gray codes of length `n' in base `q'."<<endl<<endl;
    cout<<"q and n can be any value greater or equal to 2."<<endl<<endl;
    cout<<"enter the length:  ";
    cin>>n;
    cout<<endl<<"enter the alphabet size:  ";
    cin>>q;

    if((n<=1) || (q<=1))
    {
        cout<<endl<<"incompatible parameters"<<endl;
        exit(ERROR_EXIT);
    }

    int c[n+1]; /* the maximum for each digit */
    int g[n+1]; /* the Gray code */
    int u[n+1]; /* +1 or -1 */
    int j,k,i;
    int w=0;
    for (i=0; i<=n; i++)
    {
        g[i]=0;
        u[i]=1;
        c[i]=q;
    };
     int counter=0;
     int dec=0;
     cout<<endl<<"gray codes"<<"     "<<"weight"<<"     "<<"index"<<endl;
    while (g[n]==0)
    {
        for (int j=n-1; j>=0; j--)
        {
          cout<<g[j]<<" ";
          w=w+g[j];
          dec+=g[j]*pow(q,j);
        }
        cout<<"              "<<w<<"              "<<counter;
        dec=0;
        cout<<endl;
        w=0;
        i=0; /* enumerate next Gray code */
        k=g[0]+u[0];
        while ((k>=c[i]) || (k<0))
            {
            u[i]=-u[i];
            i++;
            k=g[i]+u[i];
            };
        g[i]=k;
        counter ++;
    };
cout<<endl<<counter<<endl;

    system ("pause");
    return 0;
}
