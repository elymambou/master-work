#include <iostream>
#include <math.h>
#include <stdlib.h>
using namespace std;
void display ( int arr[], int length);
void initialise ( int arr[], int length);
const int ERROR_EXIT=-4664;
void dectob(int arr[], int n, int length, int q);

int main()
{
    int length=0;
    int abase=0;
    int bbase=0;
    cout<<"This code will convert a codeword from base a to base b"<<endl<<endl;
    cout<<"enter the length:  ";
    cin>>length;
    cout<<endl<<"enter initial base:  ";
    cin>>abase;

    if((length<=1) || (abase<=1))
    {
        cout<<endl<<"wrong parameters"<<endl;
        exit(ERROR_EXIT);
    }
    int input=0;
    int codeword[length];
    int result[2*length];

    cout<<endl<<"Enter the codeword"<<endl;
    for(int a=0; a<length; a++)
    {
        cin>>input;
        if(input<0 || input>=abase)
        {
        cout<<endl<<"wrong input"<<endl;
        exit(ERROR_EXIT);
        }
        else
        codeword[a]=input;
    }
    cout<<endl<<"enter final base:  ";
    cin>>bbase;
    if(bbase<=1)
    {
        cout<<endl<<"wrong parameters"<<endl;
        exit(ERROR_EXIT);
    }
    cout<<endl<<"Here is the codeword that you entered:  ";
    display(codeword, length);
    int dec=0;

    for (int j=length-1; j>=0; j--)
        {
           dec+=codeword[length-j-1]*pow(abase,j);
        }
        cout<<endl<<"decimal base: "<<endl;
        cout<<dec;
        initialise(result, 2*length);
        cout<<endl;
        cout<<"base "<<bbase<<endl;
        dectob(result, dec,2*length, bbase);
        display(result, 2*length);
    return 0;
}


void initialise ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    arr[c]=0;
}

void display ( int arr[], int length)
{
    for (int c=0; c<length; c++)
    cout<<arr[c]<<" ";
}
void dectob(int arr[], int n, int length, int q)
{
    int rem=0;
    int i=0;
    while(n!=0)
    {
        rem=n%q;
        n/=q;
        arr[length -i-1]=rem;
        i++;
    }
}
